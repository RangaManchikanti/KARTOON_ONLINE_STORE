<?php

$con=mysqli_connect("localhost","root","","kartoon") or die(mysqli_error($con));
?>
